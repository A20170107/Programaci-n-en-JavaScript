document.write("<h1>Bienvenido a la pagina de JavaScript</h1>");
var nom = prompt("Ingrese su nombre");
document.write(
  "Hola" + nom + "es tu primer contacto con la programacion en JavaScript"
);
